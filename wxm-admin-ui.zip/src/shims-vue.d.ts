
declare module 'element-plus/dist/locale/zh-cn.mjs'
declare module 'element-plus/dist/locale/en.mjs'
declare module 'qs'
declare module 'vue-cropper'
declare module 'js-md5'

