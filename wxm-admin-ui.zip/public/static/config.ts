export const config = {
  useAllGrey: true,
  useLoginGrey: true
}
