
declare module '@kangc/v-md-editor';
declare module '@kangc/v-md-editor/lib/theme/vuepress.js'
declare module 'vue-grid-layout-v3';
