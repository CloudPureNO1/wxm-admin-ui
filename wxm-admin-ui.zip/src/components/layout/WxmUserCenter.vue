<template>
    <div class="user-center">
        <ImageCropping />
    </div>
</template>

<script lang="ts" setup>
  import ImageCropping from '../img/ImageCropping.vue'

</script>

<style scoped lang="scss">

</style>
