// 请求地址
const BASE_URL = '/api'
// const BASE_URL = '/socket'
export default {
  BASE_URL
}
