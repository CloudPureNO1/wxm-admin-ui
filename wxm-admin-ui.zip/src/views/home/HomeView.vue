<template>
    <div class="wxm-home">
        This is the HomePage!
    </div>
</template>
