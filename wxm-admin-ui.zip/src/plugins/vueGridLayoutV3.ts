import VueGridLayout from 'vue-grid-layout-v3'

export default VueGridLayout
