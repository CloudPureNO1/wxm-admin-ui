/**
 * 用于生成唯一ID,
 * 用于取代UUID,和使用js 生成uuid的方法
 *
 *
 * npm i nanoid
 *
 * import { nanoid } from 'nanoid'
    let id = nanoid()

    //也可以指定生成字符串的长度
    //let id = nanoid(5)
 */

export const test = ''
